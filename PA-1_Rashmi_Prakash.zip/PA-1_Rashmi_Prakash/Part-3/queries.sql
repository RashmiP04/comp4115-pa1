SELECT officeCode,city,phone
FROM offices
WHERE country IN ('UK','Australia','France');

SELECT firstname, lastname, jobtitle
FROM employees;

SELECT max(items),
       min(items),
       floor(avg(items))
FROM
(SELECT orderNumber, 
 count(orderNumber) AS items
FROM orderdetails
GROUP BY orderNumber) AS lineitems;

SELECT customerNumber,checkNumber,paymentDate,amount
FROM payments
WHERE amount = (
 SELECT MAX(amount) 
        FROM payments
);

SELECT customerNumber,checkNumber,amount
FROM payments
WHERE amount > (
 SELECT AVG(amount) 
    FROM payments
);

SELECT orderNumber,customerNumber,status,shippedDate,comments
FROM orders 
WHERE orderNumber IN (
 SELECT orderNumber
 FROM   orderDetails
 GROUP BY orderNumber
 HAVING SUM(quantityOrdered * priceEach) > 50000);

SELECT EmployeeNumber,firstName,lastName,jobTitle,email
FROM employees
WHERE officeCode in
         ( select officeCode
        from offices
       where country = 'Australia');

SELECT productname,
       buyprice
FROM products AS p1
WHERE buyprice > ( 
 SELECT AVG(buyprice)
 FROM products
 WHERE productline = p1.productline);

SELECT customername,contactFirstName,contactLastName,country
FROM customers
WHERE customerNumber IN(
 SELECT DISTINCT customernumber
 FROM orders);

SELECT priceEach * quantityOrdered
FROM orderdetails
WHERE priceEach * quantityOrdered > 10000
GROUP BY orderNumber;
